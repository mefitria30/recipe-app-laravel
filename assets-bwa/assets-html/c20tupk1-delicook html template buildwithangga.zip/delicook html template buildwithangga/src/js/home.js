const swiper = new Swiper('.swiper', {
    // Optional parameters
    direction: 'horizontal',
    spaceBetween: 16,
    slidesPerView: "auto",
    slidesOffsetBefore: 20,
    slidesOffsetAfter: 20,
});